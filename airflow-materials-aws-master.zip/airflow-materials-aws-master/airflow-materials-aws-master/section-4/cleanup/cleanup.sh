#!/bin/bash

# EKS
# This can take up to 15 minutes
eksctl delete cluster --wait --name=airflow