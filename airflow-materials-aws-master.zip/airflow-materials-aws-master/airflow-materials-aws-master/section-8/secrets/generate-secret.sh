kubectl create secret generic airflow-sm -n dev \
--from-literal=aws-default-region='eu-west-3' \
--from-literal=aws-access-key-id='AKIA53Z6FABPQIVYDW4K' \
--from-literal=aws-secret-access-key='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'